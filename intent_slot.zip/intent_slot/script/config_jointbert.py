# _*_ coding：utf-8 _*_
# T:2022/6/9 15:11
# F:config_jointbert.py

class config():
    def __init__(self):
        self.vocab_file="/Users/wangbaomiao/Desktop/人机交互/CCIR-Cup-master/data/user_data/pretrained_model/ernie/vocab.txt"
