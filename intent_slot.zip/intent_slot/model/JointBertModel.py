#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2021/9/8 14:40
# @Author  : JJkinging
# @File    : model.py
import torch.nn as nn
from transformers import BertModel
from intent_slot.model.torchcrf import CRF
import torch


class JointBertModel(nn.Module):
    def __init__(self, bert_model_path, bert_hidden_size, intent_tag_size, slot_tag_size, device):
        super(JointBertModel, self).__init__()
        self.bert_model_path = bert_model_path
        self.bert_hidden_size = bert_hidden_size
        self.intent_tag_size = intent_tag_size
        #self.slot_none_tag_size = slot_none_tag_size
        self.slot_tag_size = slot_tag_size
        self.device = device
        # 加载bert模型，这个路径文件夹下有bert_config.json配置文件和model.bin模型的权重文件
        self.bert = BertModel.from_pretrained(self.bert_model_path)
        # 加载CRF模型
        self.CRF = CRF(num_tags=self.slot_tag_size, batch_first=True)
        # hidden_size,隐藏神经元的个数
        # 分类，
        self.intent_classification = nn.Linear(self.bert_hidden_size, self.intent_tag_size)
        #self.slot_none_classification = nn.Linear(self.bert_hidden_size, self.slot_none_tag_size)
        self.slot_classification = nn.Linear(self.bert_hidden_size, self.slot_tag_size)
        #
        self.Dropout = nn.Dropout(p=0.5)

    def forward(self, input_ids, input_mask):
        batch_size = input_ids.size(0)
        seq_len = input_ids.size(1)
        utter_encoding = self.bert(input_ids, input_mask)
        # 做bert的encoding
        sequence_output = utter_encoding[0] # 句子的输出内容
        pooled_output = utter_encoding[1] # 句首CLS的输出内容
        # 做一层dropout
        pooled_output = self.Dropout(pooled_output)
        sequence_output = self.Dropout(sequence_output)
        # 做一层线性分类
        intent_logits = self.intent_classification(pooled_output)  # 由句首的CLS判断Intent
        slot_logits = self.slot_classification(sequence_output)  # 由句子内容判断标准槽位
        # slot_none_logits = self.slot_none_classification(pooled_output) #由句首的CLS判断non标准槽位

        return intent_logits, slot_logits

    def slot_loss(self, feats, slot_ids, mask):
        ''' 做训练时用
        :param feats: the output of BiLSTM and Liner
        :param slot_ids:
        :param mask:
        :return:
        '''
        # device可以指定GPU或CPU
        # cuda只能指定GPU
        feats = feats.to(self.device)
        slot_ids = slot_ids.to(self.device)
        mask = mask.to(self.device)
        # 从可选的标注序列中，选取最靠谱的
        # 训练直接输出loss值，预测则会输出tensor
        loss_value = self.CRF(emissions=feats, tags=slot_ids,
                              mask=mask,
                              reduction='mean')
        return -loss_value

    def slot_predict(self, feats, mask, id2slot):
        feats = feats.to(self.device)
        mask = mask.to(self.device)
        slot2id = {value: key for key, value in id2slot.items()}
        # 做验证和测试时用
        out_path = self.CRF.decode(emissions=feats, mask=mask)
        out_path = [[id2slot[idx] for idx in one_data] for one_data in out_path]
        for out in out_path:
            for i, tag in enumerate(out):  # tag为O、B-*、I-* 等等
                if tag.startswith('I-'):  # 当前tag为I-开头
                    if i == 0:  # 0位置应该是[START]
                        out[i] = '[START]'
                    elif out[i-1] == 'O' or out[i-1] == '[START]':  # 但是前一个tag不是以B-开头的
                        out[i] = id2slot[slot2id[tag]-1]  # 将其纠正为对应的B-开头的tag

        out_path = [[slot2id[idx] for idx in one_data] for one_data in out_path]

        return out_path
