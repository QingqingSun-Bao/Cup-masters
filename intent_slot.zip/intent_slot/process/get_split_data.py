# _*_ coding：utf-8 _*_
# T:2022/6/8 14:54
# F:get_split_data.py

from confige import confige
import random
import numpy as np



def get_data(int_label):
    with open(path + "/" + int_label + "/new_seq_out.txt", "r", encoding="utf-8") as f:
        lines = f.readlines()
    seq_out_ = [l.strip("\n") for l in lines]
    with open(path + "/" + int_label + "/new_seq_in.txt", "r", encoding="utf-8") as f:
        lines = f.readlines()
    seq_in_ = [l.strip("\n") for l in lines]
    with open(path + "/" + int_label + "/new_intent_label.txt", "r", encoding="utf-8") as f:
        lines = f.readlines()
    intent_ = [l.strip("\n") for l in lines]

    return seq_in_,seq_out_,intent_


def write_in(train_test_dev,seq_in,seq_out,intent):
    with open(c.data_save_path+"/"+train_test_dev+"_data/"+train_test_dev+"_seq_in.text", "w", encoding="utf-8") as f:
        #print(seq_in)
        for text in seq_in:
            #print(text)
            f.write("".join(text))
            f.write("\n")

    with open(c.data_save_path+"/"+train_test_dev+"_data/"+train_test_dev+"_seq_out.text", "w", encoding="utf-8") as f:
        for text in seq_out:
            f.write("".join(text))
            f.write("\n")

    with open(c.data_save_path+"/"+train_test_dev+"_data/"+train_test_dev+"_intent_label.text", "w", encoding="utf-8") as f:
        #print(len(intent))
        for text in intent:
            f.write(text)
            f.write("\n")


if __name__=="__main__":
    c=confige()
    intent_label=["Math_Calculations","Traffic_Restrict","Wikipedia_Query","History_Query","Exchange_Query",
              "Stock_Query","Joke_Query","Constellation_Query","Translation_Query","Unit_Conversation",
              "Company_Introduction","Chat_Query"]
    path=c.data_load_path

    # TODO 样本量
    k=1000

    train_seq_in,train_seq_out,train_intent=[],[],[]
    test_seq_in, test_seq_out, test_intent = [], [], []
    dev_seq_in, dev_seq_out, dev_intent = [], [], []
    for int_ in intent_label:
        seq_in_,seq_out_,intent_=get_data(int_)
        num=[i for i in range(len(seq_out_))]

        # 随机抽样的下标值,样本不够的可以重复采样
        if len(seq_out_)>1000:
            ran_list = random.sample(num, k)
        else:
            ran_list=np.random.choice(num,k)


        # 下标对应的样本
        seq_out=[seq_out_[i] for i in ran_list]
        seq_in=[seq_in_[i] for i in ran_list]
        intent=[intent_[i] for i in ran_list]

        # 训练集

        train_seq_in.extend(seq_in[:800])
        train_seq_out.extend(seq_out[:800])
        train_intent.extend(intent[:800])
        # print(train_seq_in)
        # print(train_seq_out)
        # print(train_intent)

        # 测试集
        test_seq_in.extend(seq_in[800:900])
        test_seq_out.extend(seq_out[800:900])
        test_intent.extend(intent[800:900])
        #
        # # 验证集
        dev_seq_in.extend(seq_in[900:k])
        dev_seq_out.extend(seq_out[900:k])
        dev_intent.extend(intent[900:k])


    # 写入文件
    write_in("train",train_seq_in,train_seq_out,train_intent)
    write_in("test", test_seq_in, test_seq_out, test_intent)
    write_in("dev", dev_seq_in, dev_seq_out, dev_intent)
    print("train",len(train_intent),len(train_seq_in),len(train_seq_out))
    print("test",len(test_intent),len(test_seq_in),len(test_seq_out))
    print("dev",len(dev_intent),len(dev_seq_in),len(dev_seq_out))





