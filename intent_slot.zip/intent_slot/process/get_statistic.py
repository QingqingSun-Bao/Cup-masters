# _*_ coding：utf-8 _*_
# T:2022/6/8 14:45
# F:get_statistic.py


if __name__=="__main__":
   intent_label=["Math_Calculations","Traffic_Restrict","Wikipedia_Query","History_Query","Exchange_Query",
              "Stock_Query","Joke_Query","Constellation_Query","Translation_Query","Unit_Conversation",
              "Company_Introduction","Chat_Query","FilmTele-Play","Music-Play","Weather-Query","Calendar-Query",
                 "Alarm-Update","HomeAppliance-Control"]
   path="/Users/wangbaomiao/Desktop/人机交互/CCIR-Cup-master/intent_slot/new_data"
   slot_label=[]
   for int_label in intent_label:
        with open(path+"/"+int_label+"/new_seq_out.txt","r",encoding="utf-8") as f:
              lines=f.readlines()
        line=[l.strip("\n") for l in lines]
        print(int_label,len(line))
        for text in line:
            text=text.split(" ")
            for m in text:
                if m not in slot_label:
                     slot_label.extend([m])

   for i in slot_label:
       print(i)
   print(len(slot_label))