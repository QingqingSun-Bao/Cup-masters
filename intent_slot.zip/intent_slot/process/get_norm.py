# _*_ coding：utf-8 _*_
# T:2022/6/8 14:22
# F:get_norm.py

##统一符号

if __name__=="__main__":
   intent_label=["Math_Calculations","Traffic_Restrict","Wikipedia_Query","History_Query","Exchange_Query",
              "Stock_Query","Joke_Query","Constellation_Query","Translation_Query","Unit_Conversation",
              "Company_Introduction","Chat_Query"]
   path="/Users/wangbaomiao/Desktop/人机交互/CCIR-Cup-master/intent_slot/new_data"
   for int_label in intent_label:
        with open(path+"/"+int_label+"/new_seq_out.txt","r",encoding="utf-8") as f:
              lines=f.readlines()
        line=[l.strip("\n") for l in lines]
        print(int_label,len(line))
        new_out=[]
        for out in line:
            out=out.split(" ")
            for inx,text in enumerate(out):
                if text=="o":
                    out[inx]="0"
            new_out.append(out)
           # print(out)
        # new_out=[["0" if m=="o" else m for m in out[0] ] for out in line]
        # print(new_out)
        with open(path+"/"+int_label+"/new_seq_out.txt","w") as f:
              for m in new_out:
                  f.write(" ".join(m))
                  f.write("\n")

