# _*_ coding：utf-8 _*_
# T:2022/6/8 14:56
# F:confige.py


class confige():
    def __init__(self):
        self.data_save_path="/Users/wangbaomiao/Desktop/人机交互/CCIR-Cup-master/intent_slot/data"
        self.data_load_path="/Users/wangbaomiao/Desktop/人机交互/CCIR-Cup-master/intent_slot/new_data"
